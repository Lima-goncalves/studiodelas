const { DataTypes } = require('sequelize')

const db = require('../db/conn')

const Contato = db.define('Contato', {
  nome: {
    type: DataTypes.STRING,
  },
  email: {
    type: DataTypes.STRING,
  },
  telefone: {
    type: DataTypes.STRING,
  },
  mensagem: {
    type: DataTypes.TEXT,
  },
})

module.exports = Contato
