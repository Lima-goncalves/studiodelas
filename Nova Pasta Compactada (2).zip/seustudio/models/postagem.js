const { DataTypes } = require('sequelize')

const db = require('../db/conn')

const postagem = db.define('postagem', {
  titulo: {
    type: DataTypes.STRING
  },
  conteudo: {
    type: DataTypes.TEXT
  }
})

module.exports = postagem