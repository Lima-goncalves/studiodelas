const { DataTypes } = require('sequelize')

const db = require('../db/conn')

const Usuario = db.define('Usuario', {
  nome: {
    type: DataTypes.STRING
    
  },
  Sobrenome: {
    type: DataTypes.STRING
  },
  idade: {
    type: DataTypes.INTEGER
  },
})

module.exports = Usuario
