const express = require('express')
const router = express.Router()
const PostagemController = require('../controllers/PostagemController')


router.get('/formulario', PostagemController.createformulario)
router.post('/addformulario', PostagemController.respostaformulario)
router.get('/allpostagem', PostagemController.postagemformulario)
router.get('/teste1', PostagemController.teste1formulario)
router.post('/remove', PostagemController.removepost)
router.get('/delete/:id', PostagemController.deleteformulario)

router.get('/menu', PostagemController.createmenu)
module.exports = router
