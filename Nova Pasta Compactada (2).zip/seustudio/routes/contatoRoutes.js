const express = require('express')
const router = express.Router()
const ContatoController = require('../controllers/ContatoController')

router.post('/addcontato', ContatoController.respostacontato)

module.exports = router
