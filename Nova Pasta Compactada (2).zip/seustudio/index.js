const express = require('express')
const exphbs = require('express-handlebars')
const path = require("path")
const app = express()
//conexao com bamco de dados mysql
const conn = require('./db/conn')

//criando sa tabelas mysql 
const Aluno = require('./models/Aluno')

const postagem = require('./models/postagem')

const Usuario= require('./models/usuario')
const Contato= require('./models/Contato')
//criando uma rota
const alunoRoutes = require('./routes/alunosRoutes')
const formularioRoutes = require('./routes/formularioRoutes')
const contatoRoutes = require('./routes/contatoRoutes')
app.engine('handlebars', exphbs())
app.set('view engine', 'handlebars')

app.use(
  express.urlencoded({
    extended: true,
  }),
)
//piblic
app.use(express.json())

app.use(express.static(path.join(__dirname,"public")))

app.use('/alunos',alunoRoutes,formularioRoutes)
app.use('/post',formularioRoutes,contatoRoutes)
app.get('')
conn
  .sync()
  .then(() => {
    app.listen(3000)
  })
  .catch((err) => console.log(err))
