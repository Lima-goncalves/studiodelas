
const Contato= require('../models/Contato')



module.exports = class ContatoController {
    static respostacontato(req, res) {
    
        const post = {
       
          nome:req.body.nome,
          email:req.body.email,
          telefone:req.body.numero,
          mensagem: req.body.mensagem,
        }
    
        Contato.create(post)
          .then (res.redirect('/post/menu#contact'))
          .catch((err) => console.log())
      }
}