const postagem = require('../models/postagem')
const Postagem= require('../models/postagem')
const { post } = require('../routes/alunosRoutes')


module.exports = class PostagemController {
  static createformulario(req, res) {
    res.render('post/formulario')
  }
  static createmenu(req, res) {
    res.render('post/menu')
  }
  static teste1formulario(req, res) {
    res.redirect('/post/allpostagem')
  }
  teste1formulari
  static respostaformulario(req, res) {
    
    const post = {
      titulo: req.body.titulo,
      conteudo: req.body.Conteudo
    }

    Postagem.create(post)
      .then (res.redirect('/post/allpostagem'))
      .catch((err) => console.log())
  }
  static postagemformulario(req, res) {
 
    Postagem.findAll({ raw: true })
    .then(function(Postagem) {
    res.render('post/postagem',{postagem: Postagem})
    })
  }
  static deleteformulario(req, res) {
    Postagem.destroy({where: {'id': req.params.id}}).then(function(){
      res.send("postagem deletada com sucesso!")}).catch(function(erro){res.send("esta postagem n existe")
    }
  )}
  static removepost(req, res) {
    const id = req.body.id

    Postagem.destroy({ where: { id: id } })
      .then(res.redirect('/post/allpostagem'))
      .catch((err) => console.log())
  }
}